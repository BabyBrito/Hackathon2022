package hackProject.Hackathon.Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.util.List;
@SpringBootApplication
public class HackathonProjectApplication {

	public static void main(String[] args) {

		
		SpringApplication.run(HackathonProjectApplication.class, args);
		System.out.println("Hello World");

	}

}

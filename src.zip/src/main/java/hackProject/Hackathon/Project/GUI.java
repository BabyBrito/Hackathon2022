package hackProject.Hackathon.Project;

import javax.swing.*;

public class GUI {
    private JLabel ecnLabel;
    private JTextField ecnField;
    private JButton nextButton;
}
